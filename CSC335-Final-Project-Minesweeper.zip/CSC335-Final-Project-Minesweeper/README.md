# CSC335-Final-Project-Minesweeper
Repository for the final project in CSC 335. We are doing minesweeper.

## Project Description
For this project, we create a game Minesweeper in a group of four.
Before starting the game, you should have the JavaFX library included in the project.

## Play The Game
1. Open the file OptionsWindow.java and run it, a option window should pop up to your screen.
   You can modify the difficulty of the game on your own by assigning the size of the board and the number of bombs!
   Recommand settings:
   * 10X10 board with 9 bombs.
   * 16X16 board with 40 bombs.
   * 30X16 board with 99 bombs.
2. **WOW factor** : 
   You should be able to customize the theme of the game by entering the rgb value in the option window!
	 
3. Click START buttom when done setting up the game. You should be able to play the game!! Enjoy!!
   * left click to reveal a location, if there has a bomb, you lose.
   * right click to place a flag, which you think there has a bomb.
   * once the number of flags is equal to the number of bombs, it will check if you win or not, if you win, all the color on the flagged block should be green.
   
   
   
